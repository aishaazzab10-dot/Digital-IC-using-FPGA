module decoder (
    input wire [3:0] rise_count,
    input wire [3:0] fall_count,
    input wire [3:0] total_count,

    output wire [6:0] rise_tens,
    output wire [6:0] rise_units,
    output wire [6:0] fall_tens,
    output wire [6:0] fall_units,
    output wire [6:0] total_tens,
    output wire [6:0] total_units
);

    wire [3:0] rise_tens_digit;
    wire [3:0] rise_units_digit;
    wire [3:0] fall_tens_digit;
    wire [3:0] fall_units_digit;
    wire [3:0] total_tens_digit;
    wire [3:0] total_units_digit;

    assign rise_tens_digit = rise_count / 10;
    assign rise_units_digit = rise_count % 10;

    assign fall_tens_digit = fall_count / 10;
    assign fall_units_digit = fall_count % 10;

    assign total_tens_digit = total_count / 10;
    assign total_units_digit = total_count % 10;

    seven_seg u1 (
        .digit(rise_tens_digit),
        .seg(rise_tens)
    );

    seven_seg u2 (
        .digit(rise_units_digit),
        .seg(rise_units)
    );

    seven_seg u3 (
        .digit(fall_tens_digit),
        .seg(fall_tens)
    );

    seven_seg u4 (
        .digit(fall_units_digit),
        .seg(fall_units)
    );

    seven_seg u5 (
        .digit(total_tens_digit),
        .seg(total_tens)
    );

    seven_seg u6 (
        .digit(total_units_digit),
        .seg(total_units)
    );

endmodule


module seven_seg (
    input wire [3:0] digit,
    output reg [6:0] seg
);

    always @(*) begin
        case (digit)
            4'd0: seg = 7'b0000001;
            4'd1: seg = 7'b1001111;
            4'd2: seg = 7'b0010010;
            4'd3: seg = 7'b0000110;
            4'd4: seg = 7'b1001100;
            4'd5: seg = 7'b0100100;
            4'd6: seg = 7'b0100000;
            4'd7: seg = 7'b0001111;
            4'd8: seg = 7'b0000000;
            4'd9: seg = 7'b0000100;
            default: seg = 7'b1111111;
        endcase
    end

endmodule
