module rising (
    input wire clk,
    input wire reset_n,
    input wire in_signal,
    output reg [3:0] rise_count,
    output reg [3:0] fall_count,
    output reg [3:0] total_count
);

    reg in_d;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            in_d <= 1'b0;
            rise_count <= 4'd0;
            fall_count <= 4'd0;
            total_count <= 4'd0;
        end
        else begin
            if (in_signal && !in_d)
                rise_count <= rise_count + 1'b1;

            if (!in_signal && in_d)
                fall_count <= fall_count + 1'b1;

            if (in_signal != in_d)
                total_count <= total_count + 1'b1;

            in_d <= in_signal;
        end
    end

endmodule
