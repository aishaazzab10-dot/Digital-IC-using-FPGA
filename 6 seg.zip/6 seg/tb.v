`timescale 1ns/1ps

module tb_top_level;

    reg clk;
    reg reset_n;
    reg in_signal;

    wire [6:0] rise_tens;
    wire [6:0] rise_units;
    wire [6:0] fall_tens;
    wire [6:0] fall_units;
    wire [6:0] total_tens;
    wire [6:0] total_units;

    top_level dut (
        .clk(clk),
        .reset_n(reset_n),
        .in_signal(in_signal),
        .rise_tens(rise_tens),
        .rise_units(rise_units),
        .fall_tens(fall_tens),
        .fall_units(fall_units),
        .total_tens(total_tens),
        .total_units(total_units)
    );

    initial begin
        clk = 1'b0;
        forever #5 clk = ~clk;
    end

    initial begin
        reset_n = 1'b0;
        in_signal = 1'b0;

        #20;
        reset_n = 1'b1;

        #20;
        in_signal = 1'b1;

        #20;
        in_signal = 1'b0;

        #20;
        in_signal = 1'b1;

        #20;
        in_signal = 1'b0;

        #20;
        in_signal = 1'b1;

        #20;
        in_signal = 1'b0;

        #50;
        $finish;
    end

endmodule
