module top_level (
    input wire clk,
    input wire reset_n,
    input wire in_signal,

    output wire [6:0] rise_tens,
    output wire [6:0] rise_units,

    output wire [6:0] fall_tens,
    output wire [6:0] fall_units,

    output wire [6:0] total_tens,
    output wire [6:0] total_units
);

    wire [3:0] rise_count;
    wire [3:0] fall_count;
    wire [3:0] total_count;

    rising u_rising (
        .clk(clk),
        .reset_n(reset_n),
        .in_signal(in_signal),
        .rise_count(rise_count),
        .fall_count(fall_count),
        .total_count(total_count)
    );

    decoder u_decoder (
        .rise_count(rise_count),
        .fall_count(fall_count),
        .total_count(total_count),
        .rise_tens(rise_tens),
        .rise_units(rise_units),
        .fall_tens(fall_tens),
        .fall_units(fall_units),
        .total_tens(total_tens),
        .total_units(total_units)
    );

endmodule
