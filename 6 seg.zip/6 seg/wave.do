onerror {resume}
quietly WaveActivateNextPane {} 0
add wave -noupdate /tb_top_level/clk
add wave -noupdate /tb_top_level/reset_n
add wave -noupdate /tb_top_level/in_signal
add wave -noupdate /tb_top_level/rise_tens
add wave -noupdate /tb_top_level/rise_units
add wave -noupdate /tb_top_level/fall_tens
add wave -noupdate /tb_top_level/fall_units
add wave -noupdate /tb_top_level/total_tens
add wave -noupdate /tb_top_level/total_units
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {0 ps} 0}
quietly wave cursor active 0
configure wave -namecolwidth 150
configure wave -valuecolwidth 100
configure wave -justifyvalue left
configure wave -signalnamewidth 0
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 0
configure wave -gridperiod 1
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ps
update
WaveRestoreZoom {0 ps} {199500 ps}
