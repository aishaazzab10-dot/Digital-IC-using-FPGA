onerror {resume}
quietly WaveActivateNextPane {} 0
add wave -noupdate /alu_test/WIDTH
add wave -noupdate /alu_test/PASS0
add wave -noupdate /alu_test/PASS1
add wave -noupdate /alu_test/ADD
add wave -noupdate /alu_test/AND
add wave -noupdate /alu_test/XOR
add wave -noupdate /alu_test/PASSB
add wave -noupdate /alu_test/PASS6
add wave -noupdate /alu_test/PASS7
add wave -noupdate /alu_test/opcode
add wave -noupdate /alu_test/in_a
add wave -noupdate /alu_test/in_b
add wave -noupdate /alu_test/a_is_zero
add wave -noupdate /alu_test/alu_out
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {0 ns} 0}
quietly wave cursor active 0
configure wave -namecolwidth 150
configure wave -valuecolwidth 100
configure wave -justifyvalue left
configure wave -signalnamewidth 0
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 0
configure wave -gridperiod 1
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ps
update
WaveRestoreZoom {0 ns} {9 ns}
