module Data_Scrambler(

    input signed [7:0] data_in,
    input [1:0] scramble_key,
    input [1:0] op_mode,
    input sleep_mode,

    output reg [7:0] data_out,
    output reg parity_err,
    output reg is_zero

);

always @(*) begin

    // Sleep Mode
    if (sleep_mode) begin

        data_out = 8'b00000000;
        parity_err = 1'b0;
        is_zero = 1'b1;

    end

    else begin

        case(op_mode)

            // Pass Through
            2'b00:
                data_out = data_in;

            // Scramble
            2'b01:
                data_out = data_in ^ {4{scramble_key}};

            // Arithmetic Scale
            2'b10:
                data_out = data_in >>> 2;

            // Nibble Swap
            2'b11:
                data_out = {data_in[3:0], data_in[7:4]};

            default:
                data_out = 8'b00000000;

        endcase

        // Even parity detection
        parity_err = ~^data_out;

        // Zero detection
        is_zero = !data_out;

    end

end

endmodule
