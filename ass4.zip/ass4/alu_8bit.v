module alu_8bit(
    input  [7:0] A,
    input  [7:0] B,
    input        Cin,
    input  [4:0] Control,
    output reg [15:0] Out
);

always @(*) begin

    case (Control)

        5'b00000: Out = A + B;

        5'b00001: Out = A + B + 1;

        5'b00010: Out = A + (~B) + 1;

        5'b00011: Out = A + (~B);

        5'b00100: Out = A + 1;

        5'b00101: Out = A - 1;

        5'b00110: Out = (A * B) + 1;

        5'b00111: Out = A & B;

        5'b01000: Out = A | B;

        5'b01001: Out = A ^ B;

        5'b01010: Out = ~A;

        5'b01011: Out = ~(A & B);

        // Shift Left Logical
        5'b01100: Out = {A, 8'b0} << B;

        // Shift Right Logical
        5'b01101: Out = A >> B;

        // Shift Left Arithmetic
        5'b01110: Out = A <<< B;

        // Shift Right Arithmetic
        5'b01111: Out = $signed(A) >>> B;

        // Rotate Right
        5'b10000: Out = {8'b0, (A >> B) | (A << (8-B))};

        // Rotate Left
        5'b10001: Out = {8'b0, (A << B) | (A >> (8-B))};

        // Greater value
        5'b10010: begin
            if (A >= B)
                Out = {8'b0, A};
            else
                Out = {8'b0, B};
        end

        // MUX
        5'b10011: begin
            if (Cin == 1'b0)
                Out = {8'b0, A};
            else
                Out = {8'b0, B};
        end

        // Complement
        5'b10100: Out = {~A, ~B};

        // Compare
        5'b10101: begin
            Out = 16'b0;

            Out[0] = (A >= B);
            Out[1] = (A > B);
            Out[2] = (A == B);
            Out[3] = (A <= B);
            Out[4] = (A < B);
            Out[5] = (A != B);
        end

        // Parity
        5'b10110: begin
            Out = 16'b0;
            Out[0] = ^A;
            Out[1] = ~^B;
        end

        default: Out = 16'b0;

    endcase

end

endmodule
