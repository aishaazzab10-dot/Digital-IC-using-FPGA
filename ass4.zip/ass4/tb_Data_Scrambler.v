module tb_Data_Scrambler;

reg signed [7:0] data_in;
reg [1:0] scramble_key;
reg [1:0] op_mode;
reg sleep_mode;

wire [7:0] data_out;
wire parity_err;
wire is_zero;


Data_Scrambler DUT(

    .data_in(data_in),
    .scramble_key(scramble_key),
    .op_mode(op_mode),
    .sleep_mode(sleep_mode),

    .data_out(data_out),
    .parity_err(parity_err),
    .is_zero(is_zero)

);


initial begin

    // Initial values
    data_in = 8'b10101010;
    scramble_key = 2'b10;
    sleep_mode = 0;


    // Mode 00 Pass Through
    op_mode = 2'b00;
    #10;


    // Mode 01 Scramble
    op_mode = 2'b01;
    #10;


    // Mode 10 Arithmetic Shift
    data_in = 8'b10000000;
    op_mode = 2'b10;
    #10;


    // Mode 11 Nibble Swap
    data_in = 8'b10110010;
    op_mode = 2'b11;
    #10;


    // Zero test
    data_in = 8'b00000000;
    op_mode = 2'b00;
    #10;


    // Sleep Mode
    data_in = 8'b11111111;
    sleep_mode = 1;
    #10;


    // Wake up
    sleep_mode = 0;
    op_mode = 2'b00;
    #10;


    $stop;

end


initial begin

    $monitor(
        "Time=%0t | data_in=%b | mode=%b | sleep=%b | data_out=%b | parity_err=%b | is_zero=%b",
        $time,
        data_in,
        op_mode,
        sleep_mode,
        data_out,
        parity_err,
        is_zero
    );

end

endmodule
