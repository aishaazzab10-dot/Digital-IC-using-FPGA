module tb_alu_8bit;

reg [7:0] A;
reg [7:0] B;
reg Cin;
reg [4:0] Control;

wire [15:0] Out;


alu_8bit DUT (
    .A(A),
    .B(B),
    .Cin(Cin),
    .Control(Control),
    .Out(Out)
);


initial begin

    A = 8'd10;
    B = 8'd5;
    Cin = 0;

    // ADD
    Control = 5'b00000;
    #10;

    // ADD with Carry
    Control = 5'b00001;
    #10;

    // SUB
    Control = 5'b00010;
    #10;

    // SUB with Borrow
    Control = 5'b00011;
    #10;

    // INC
    Control = 5'b00100;
    #10;

    // DEC
    Control = 5'b00101;
    #10;

    // MAC
    Control = 5'b00110;
    #10;

    // AND
    Control = 5'b00111;
    #10;

    // OR
    Control = 5'b01000;
    #10;

    // XOR
    Control = 5'b01001;
    #10;

    // NOT
    Control = 5'b01010;
    #10;

    // NAND
    Control = 5'b01011;
    #10;

    // Shift Left Logical
    B = 2;
    Control = 5'b01100;
    #10;

    // Shift Right Logical
    Control = 5'b01101;
    #10;

    // Shift Left Arithmetic
    Control = 5'b01110;
    #10;

    // Shift Right Arithmetic
    A = 8'b10000000;
    Control = 5'b01111;
    #10;

    // Rotate Right
    A = 8'b10110011;
    B = 2;
    Control = 5'b10000;
    #10;

    // Rotate Left
    Control = 5'b10001;
    #10;

    // Greater
    A = 20;
    B = 30;
    Control = 5'b10010;
    #10;

    // MUX
    Cin = 0;
    Control = 5'b10011;
    #10;

    Cin = 1;
    #10;

    // Complement
    Control = 5'b10100;
    #10;

    // Compare
    Control = 5'b10101;
    #10;

    // Parity
    Control = 5'b10110;
    #10;

    $stop;

end

endmodule
