
module controller (
    input  wire [2:0] opcode,
    input  wire [2:0] phase,
    input  wire       zero,

    output reg        sel,
    output reg        rd,
    output reg        ld_ir,
    output reg        inc_pc,
    output reg        halt,
    output reg        ld_pc,
    output reg        data_e,
    output reg        ld_ac,
    output reg        wr
);

reg alu_op;
reg skz;
reg jmp;
reg sto;

always @(*) begin

    // Intermediate terms
    alu_op = (opcode == 3'b010) ||
             (opcode == 3'b011) ||
             (opcode == 3'b100) ||
             (opcode == 3'b101);

    skz = (opcode == 3'b001);
    jmp = (opcode == 3'b111);
    sto = (opcode == 3'b110);

    // Default values
    sel    = 1'b0;
    rd     = 1'b0;
    ld_ir  = 1'b0;
    inc_pc = 1'b0;
    halt   = 1'b0;
    ld_pc  = 1'b0;
    data_e = 1'b0;
    ld_ac  = 1'b0;
    wr     = 1'b0;

    case (phase)

        // INST_ADDR
        3'd0: begin
            sel = 1'b1;
        end

        // INST_FETCH
        3'd1: begin
            sel = 1'b1;
            rd  = 1'b1;
        end

        // INST_LOAD
        3'd2: begin
            sel   = 1'b1;
            rd    = 1'b1;
            ld_ir = 1'b1;
        end

        // IDLE
        3'd3: begin
            sel   = 1'b1;
            rd    = 1'b1;
            ld_ir = 1'b1;
        end

        // OP_ADDR
        3'd4: begin
            inc_pc = 1'b1;

            if (opcode == 3'b000)
                halt = 1'b1;

            if (skz && zero)
                inc_pc = 1'b1;
        end

        // OP_FETCH
        3'd5: begin
            if (alu_op)
                rd = 1'b1;
        end

        // ALU_OP
        3'd6: begin
            if (alu_op)
                rd = 1'b1;

            if (jmp)
                ld_pc = 1'b1;
        end

        // STORE
        3'd7: begin
            if (alu_op) begin
                rd    = 1'b1;
                ld_ac = 1'b1;
            end

            if (sto) begin
                data_e = 1'b1;
                wr     = 1'b1;
            end

            if (jmp)
                ld_pc = 1'b1;
        end

        default: begin
            sel    = 1'b0;
            rd     = 1'b0;
            ld_ir  = 1'b0;
            inc_pc = 1'b0;
            halt   = 1'b0;
            ld_pc  = 1'b0;
            data_e = 1'b0;
            ld_ac  = 1'b0;
            wr     = 1'b0;
        end

    endcase
end

endmodule