onerror {resume}
quietly WaveActivateNextPane {} 0
add wave -noupdate /controller_test/HLT
add wave -noupdate /controller_test/SKZ
add wave -noupdate /controller_test/ADD
add wave -noupdate /controller_test/AND
add wave -noupdate /controller_test/XOR
add wave -noupdate /controller_test/LDA
add wave -noupdate /controller_test/STO
add wave -noupdate /controller_test/JMP
add wave -noupdate /controller_test/opcode
add wave -noupdate /controller_test/phase
add wave -noupdate /controller_test/zero
add wave -noupdate /controller_test/sel
add wave -noupdate /controller_test/rd
add wave -noupdate /controller_test/ld_ir
add wave -noupdate /controller_test/inc_pc
add wave -noupdate /controller_test/halt
add wave -noupdate /controller_test/ld_pc
add wave -noupdate /controller_test/data_e
add wave -noupdate /controller_test/ld_ac
add wave -noupdate /controller_test/wr
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {0 ns} 0}
quietly wave cursor active 0
configure wave -namecolwidth 150
configure wave -valuecolwidth 100
configure wave -justifyvalue left
configure wave -signalnamewidth 0
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 0
configure wave -gridperiod 1
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ps
update
WaveRestoreZoom {0 ns} {17 ns}
