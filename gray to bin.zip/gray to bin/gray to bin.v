module gray_to_binary #(
    parameter integer WIDTH = 4
)(
    input  wire [WIDTH-1:0] In_Gray,
    output reg  [WIDTH-1:0] out_Binary
);

    integer i;

    always @(*) begin
        out_Binary[WIDTH-1] = In_Gray[WIDTH-1];

        for (i = WIDTH-2; i >= 0; i = i - 1)
            out_Binary[i] = out_Binary[i+1] ^ In_Gray[i];
    end

endmodule


module binary_to_7seg (
    input  wire [3:0] bin,
    output reg  [6:0] seg
);

    always @(*) begin
        case (bin)
            4'd0: seg = 7'b0000001;
            4'd1: seg = 7'b1001111;
            4'd2: seg = 7'b0010010;
            4'd3: seg = 7'b0000110;
            4'd4: seg = 7'b1001100;
            4'd5: seg = 7'b0100100;
            4'd6: seg = 7'b0100000;
            4'd7: seg = 7'b0001111;
            4'd8: seg = 7'b0000000;
            4'd9: seg = 7'b0000100;
            4'd10: seg = 7'b0001000;
            4'd11: seg = 7'b1100000;
            4'd12: seg = 7'b0110001;
            4'd13: seg = 7'b1000010;
            4'd14: seg = 7'b0110000;
            4'd15: seg = 7'b0111000;
            default: seg = 7'b1111111;
        endcase
    end

endmodule



