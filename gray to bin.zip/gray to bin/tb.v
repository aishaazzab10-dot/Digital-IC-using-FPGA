`timescale 1ns/1ps

module tb_gray_to_seven_seg;

    reg [3:0] In_Gray;
    wire [6:0] seg_out;

    gray_to_seven_seg dut (
        .In_Gray(In_Gray),
        .seg_out(seg_out)
    );

    initial begin

        In_Gray = 4'b0000;
        #20;

        In_Gray = 4'b0001;
        #20;

        In_Gray = 4'b0011;
        #20;

        In_Gray = 4'b0010;
        #20;

        In_Gray = 4'b0110;
        #20;

        In_Gray = 4'b0111;
        #20;

        In_Gray = 4'b0101;
        #20;

        In_Gray = 4'b0100;
        #20;

        In_Gray = 4'b1100;
        #20;

        In_Gray = 4'b1101;
        #20;

        In_Gray = 4'b1111;
        #20;

        In_Gray = 4'b1110;
        #20;

        In_Gray = 4'b1010;
        #20;

        In_Gray = 4'b1011;
        #20;

        In_Gray = 4'b1001;
        #20;

        In_Gray = 4'b1000;
        #20;

        $finish;
    end

endmodule
