module gray_to_seven_seg (
    input  wire [3:0] In_Gray,
    output wire [6:0] seg_out
);

    wire [3:0] binary;

    gray_to_binary u_gray_to_binary (
        .In_Gray(In_Gray),
        .out_Binary(binary)
    );

    binary_to_7seg u_binary_to_7seg (
        .bin(binary),
        .seg(seg_out)
    );

endmodule
