`timescale 1ns/1ps

module tb_light_chaser;

    reg clk;
    reg reset_n;
    reg hold_n;
    wire [9:0] shift_out;

    light_chaser #(
        .CLK_FREQ(100),
        .LED_FREQ(5),
        .WIDTH(10)
    ) dut (
        .clk(clk),
        .reset_n(reset_n),
        .hold_n(hold_n),
        .shift_out(shift_out)
    );

    initial begin
        clk = 1'b0;
        forever #5 clk = ~clk;
    end

    initial begin
        reset_n = 1'b0;
        hold_n  = 1'b1;

        #20;
        reset_n = 1'b1;

        #500;

        hold_n = 1'b0;
        #100;

        hold_n = 1'b1;
        #500;

        reset_n = 1'b0;
        #30;

        reset_n = 1'b1;
        #300;

        $finish;
    end

endmodule
