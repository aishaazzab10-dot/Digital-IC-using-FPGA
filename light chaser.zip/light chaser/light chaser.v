
module clock_divider #(
    parameter integer CLK_FREQ = 50000000,
    parameter integer OUT_FREQ = 8
)(
    input  wire clk,
    input  wire reset_n,
    output reg clk_out
);

    localparam integer DIV = CLK_FREQ / (2 * OUT_FREQ);

    reg [31:0] count;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            count   <= 32'd0;
            clk_out <= 1'b0;
        end
        else if (count == DIV - 1) begin
            count   <= 32'd0;
            clk_out <= ~clk_out;
        end
        else begin
            count <= count + 1'b1;
        end
    end

endmodule


module shift_register #(
    parameter integer WIDTH = 10
)(
    input  wire clk,
    input  wire reset_n,
    input  wire hold_n,
    output wire [WIDTH-1:0] shift_out
);

    reg [WIDTH-1:0] shift_reg;

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n)
            shift_reg <= {{(WIDTH-1){1'b0}},1'b1};
        else if (!hold_n)
            shift_reg <= shift_reg;
        else
            shift_reg <= {shift_reg[WIDTH-2:0],shift_reg[WIDTH-1]};
    end

    assign shift_out = shift_reg;

endmodule


module light_chaser #(
    parameter integer CLK_FREQ = 50000000,
    parameter integer LED_FREQ = 8,
    parameter integer WIDTH = 10
)(
    input  wire clk,
    input  wire reset_n,
    input  wire hold_n,
    output wire [WIDTH-1:0] shift_out
);

    wire clk_8hz;

    clock_divider #(
        .CLK_FREQ(CLK_FREQ),
        .OUT_FREQ(LED_FREQ)
    ) u_clock_divider (
        .clk(clk),
        .reset_n(reset_n),
        .clk_out(clk_8hz)
    );

    shift_register #(
        .WIDTH(WIDTH)
    ) u_shift_register (
        .clk(clk_8hz),
        .reset_n(reset_n),
        .hold_n(hold_n),
        .shift_out(shift_out)
    );

endmodule