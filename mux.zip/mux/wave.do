onerror {resume}
quietly WaveActivateNextPane {} 0
add wave -noupdate /multiplexor_test/WIDTH
add wave -noupdate /multiplexor_test/sel
add wave -noupdate /multiplexor_test/in0
add wave -noupdate /multiplexor_test/in1
add wave -noupdate /multiplexor_test/mux_out
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {0 ns} 0}
quietly wave cursor active 0
configure wave -namecolwidth 150
configure wave -valuecolwidth 100
configure wave -justifyvalue left
configure wave -signalnamewidth 0
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 0
configure wave -gridperiod 1
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ps
update
WaveRestoreZoom {0 ns} {4 ns}
