module stream_parity_gen (
    input  wire       clk,
    input  wire       reset,
    input  wire       serial_in,
    output reg        parity_out,
    output reg        valid
);

    reg [7:0] shift_reg;
    reg [3:0] count;

    always @(posedge clk) begin
        if (reset) begin
            shift_reg <= 8'b0;
            count <= 4'b0;
            parity_out <= 1'b0;
            valid <= 1'b0;
        end
        else begin
            valid <= 1'b0;

            shift_reg <= {shift_reg[6:0], serial_in};

            if (count == 4'd7) begin
                parity_out <= ^{shift_reg[6:0], serial_in};
                valid <= 1'b1;
                count <= 4'b0;
            end
            else begin
                count <= count + 1'b1;
            end
        end
    end

endmodule
