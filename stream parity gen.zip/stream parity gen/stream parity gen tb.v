`timescale 1ns/1ps

module tb_stream_parity_gen;

    reg clk;
    reg reset;
    reg serial_in;

    wire parity_out;
    wire valid;

    integer data;
    integer bit_index;
    integer expected_parity;
    integer errors;

    stream_parity_gen dut (
        .clk(clk),
        .reset(reset),
        .serial_in(serial_in),
        .parity_out(parity_out),
        .valid(valid)
    );

    initial begin
        clk = 1'b0;
        forever #5 clk = ~clk;
    end

    initial begin
        reset = 1'b1;
        serial_in = 1'b0;
        errors = 0;

        repeat (2) @(posedge clk);

        reset = 1'b0;

        for (data = 0; data < 256; data = data + 1) begin

            expected_parity = 0;

            for (bit_index = 7; bit_index >= 0; bit_index = bit_index - 1) begin
                serial_in = (data >> bit_index) & 1;

                if (serial_in)
                    expected_parity = expected_parity ^ 1;

                @(posedge clk);
            end

            #1;

            if (valid !== 1'b1) begin
                $display("ERROR: VALID is not asserted for data = %d", data);
                errors = errors + 1;
            end

            if (parity_out !== expected_parity) begin
                $display("ERROR: Data = %08b Expected = %b Actual = %b",
                         data, expected_parity, parity_out);
                errors = errors + 1;
            end

            @(posedge clk);
        end

        if (errors == 0)
            $display("EXHAUSTIVE TEST PASSED: All 256 patterns passed.");
        else
            $display("EXHAUSTIVE TEST FAILED: %d errors detected.", errors);

        $stop;
    end

endmodule
