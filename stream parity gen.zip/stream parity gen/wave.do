onerror {resume}
quietly WaveActivateNextPane {} 0
add wave -noupdate /tb_stream_parity_gen/clk
add wave -noupdate /tb_stream_parity_gen/reset
add wave -noupdate /tb_stream_parity_gen/serial_in
add wave -noupdate /tb_stream_parity_gen/parity_out
add wave -noupdate /tb_stream_parity_gen/valid
add wave -noupdate /tb_stream_parity_gen/data
add wave -noupdate /tb_stream_parity_gen/bit_index
add wave -noupdate /tb_stream_parity_gen/expected_parity
add wave -noupdate /tb_stream_parity_gen/errors
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {0 ps} 0}
quietly wave cursor active 0
configure wave -namecolwidth 150
configure wave -valuecolwidth 100
configure wave -justifyvalue left
configure wave -signalnamewidth 0
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 0
configure wave -gridperiod 1
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ps
update
WaveRestoreZoom {365641 ps} {23156756 ps}
